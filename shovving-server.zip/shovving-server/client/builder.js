/*
 Copyright (c) 2015 Feedity (feedity.com), All rights reserved */
var visframe, rtimer, lmodal, errorAlert, alertTimer, hasBar, resultslist, templateAdvRefinementResults, hidRID, chkImg, ddlSelectors, hidSelectors, initialContentAnalysisResults;
$(function() {
    visframe = $("#visframe");
    lmodal = $("#loadingmodal");
    errorAlert = $("#errorAlert");
    hasBar = $("#panelTrialUpgrade").length;
    resultslist = $("#resultslist");
    hidRID = $("#hidRID");
    chkImg = $("#panelAdvancedRefine #chkExtractImage");
    ddlSelectors = $("#ddlSelectors");
    hidSelectors = $("#hidSelectors");
    $("#templateAdvRefinementResults").length && (templateAdvRefinementResults = Handlebars.compile($("#templateAdvRefinementResults").html()));
    if (ddlSelectors.length) ddlSelectors.html(getSelectorsData()).on("change",
        function(a) {
            visframe[0].contentWindow.changeMode(this.value)
        });
    $("#panelVisualSelector a.switchmode, #panelAdvancedRefine a.switchmode").on("click", function() {
        $("#panelAdvancedRefine").toggle();
        $("#panelVisualSelector").toggle();
        return !1
    });
    $("#panelAdvancedRefine #btnAdvancedRefine").on("click", function() {
        loadAdvRefinementResults(!0);
        return !1
    });
    $("button.close", errorAlert).on("click", function() {
        clearError()
    });
    visframe.on("load", function() {
        ddlSelectors.change()
    });
    visframe.length && (setFrameHeight(),
        $(window).on("resize", function() {
            rtimer || (rtimer = setTimeout(function() {
                setFrameHeight();
                rtimer = null
            }, 50))
        }));
    $(".tooltips:enabled,span.tooltips").tooltip();
    $("#helpmodal").on("show.bs.modal", function(a) {
        a.relatedTarget && $("div.in", $(this)).collapse("hide")
    }).on("shown.bs.modal", function(a) {
        a.relatedTarget && $("#slide" + $(a.relatedTarget).data("help-slide"), $(this)).collapse("show")
    });
    $("#panelAdvancedRefine").hasClass("nodisplay") && ddlSelectors.length && "" == $("option:selected", ddlSelectors).val() && "" ==
        $("span", errorAlert).text() && "true" != $("#hidFamUser").val() && $("#helpmodal").modal("show");
    doneLoadingResults(initialContentAnalysisResults)
});

function loadAdvRefinementResults(a) {
    var b = $("#txtAdvRefineStart");
    if (b.length) {
        var c = $("#txtAdvRefineEnd");
        if ("" != b.val() && "" != c.val()) {
            a = $("#txtDescStart");
            var d = $("#txtDescEnd"),
                e = $("#txtCustomFieldStart"),
                f = $("#txtCustomFieldEnd"),
                g = $("#txtDateFormat"),
                h = 0 < e.length;
            b.val($.trim(b.val()));
            c.val($.trim(c.val()));
            a.val($.trim(a.val()));
            d.val($.trim(d.val()));
            h && (e.val($.trim(e.val())), f.val($.trim(f.val())));
            g.val($.trim(g.val()));
            $("#hidFDT").val("False");
            lmodal.modal("show");
            clearError();
            webMethod("GetAdvRefinementResults",
                JSON.stringify({
                    hidRID: $("#hidRID").val(),
                    hidURL: $("#hidURL").val(),
                    hidEFID: $("#hidEFID").val(),
                    isTrialAccount: 0 < $("#panelTrialUpgrade").length,
                    txtAdvRefineStart: b.val(),
                    txtAdvRefineEnd: c.val(),
                    txtDescStart: a.val(),
                    txtDescEnd: d.val(),
                    txtCustomFieldStart: h ? e.val() : "",
                    txtCustomFieldEnd: h ? f.val() : "",
                    txtDateFormat: g.val(),
                    isExtractImageChecked: isExtractImageChecked()
                }), doneLoadingResults, loadFailed)
        } else a ? showError("Please specify valid title start and end tags for Advanced Refinement") : doneLoadingResults()
    }
}

function doneLoadingResults(a) {
    a && a.length && a[0].ErrorMessage && ($("span", errorAlert).text(a[0].ErrorMessage), a = null);
    resultslist.length && ($("#hidFDT").val((!!(a && a.length && a[0].PubDate)).toString()), $("#hidHasResults").val((!(!a || !a.length)).toString()), resultslist.empty(), resultslist.append(templateAdvRefinementResults(a)), $("#divImageTip", resultslist).toggle(isExtractImageChecked()));
    showError()
}

function loadFailed(a) {
    showError("Failed to load Advanced Refinement results for preview. Please try again or contact us if the problem persists")
}

function getSelectorsData() {
    var a = [],
        b = $.parseJSON(hidSelectors.val()),
        c = $("#txtDescStart").prop("title"),
        d;
    $.each(b, function(b, f) {
        if (d = c && "title" != b) f = "", b += " (needs upgrade)";
        a.push('<option value="' + f + '"' + (d ? " disabled" : "") + ">" + (f ? "\u2713" : "\u2610") + " " + b + "</option>")
    });
    return a.join("")
}

function setSelectorsData() {
    var a = {},
        b;
    $("option", ddlSelectors).each(function() {
        b = this.text.match(/\s([^\s]+)/)[1];
        a[b] = this.value
    });
    hidSelectors.val(JSON.stringify(a))
}

function webMethod(a, b, c, d, e) {
    $.ajax({
        type: "POST",
        url: window.location.href + "/" + a,
        async: "undefined" === typeof e ? !0 : e,
        cache: !1,
        timeout: 3E4,
        data: b,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(a) {
            $.isFunction(c) && c(a.d)
        },
        error: function(a) {
            $.isFunction(d) && d(a.responseText)
        }
    })
}

function isExtractImageChecked() {
    return chkImg.not(":disabled") && chkImg[0].checked
}

function showError(a) {
    var b = !1;
    resetErrTimer();
    lmodal.modal("hide");
    a || "" == $("span", errorAlert).text() || (a = $("span", errorAlert).text(), b = !0);
    if (a) {
        var c = $("#panelVisualSelector").length;
        b || $("span", errorAlert).text(a);
        c || (errorAlert.append('<br /><br /><a href="." role="button" class="btn btn-danger">Try a different webpage</a>'), $("button", errorAlert).hide());
        errorAlert.show();
        c && (alertTimer = window.setTimeout(function() {
            clearError()
        }, 1E4))
    } else clearError()
}

function clearError() {
    resetErrTimer();
    errorAlert.hide();
    $("span", errorAlert).text("")
}

function resetErrTimer() {
    alertTimer && clearTimeout(alertTimer);
    alertTimer = 0
}

function setFrameHeight() {
    var a = $(window).height();
    visframe.css("height", (480 > a ? 480 : a - (hasBar ? 200 : 140)) + "px")
}

function validateEditedTitle(a) {
    a.value = trimStr(stripHTML(a.value));
    "" === a.value && (a.value = "Unknown RSS Feed")
}

function restrictTextboxEnter(a) {
    characterCode = a && a.which ? a.which : a.keyCode;
    if (13 == characterCode) a.returnValue = !1, a.cancelBubble = !0;
    else return !1
};