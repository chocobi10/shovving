$(function() {
    
    window.addEventListener("message", processFn, false);
    function processFn(event) {
        console.log(event);
		var response = event.data;
        var type = response.type;
        var data = response.data;
        if(type == 'node'){
            var btn_class = ".sv_" + data;
		    $(btn_class).addClass('active');
        }else if(type == 'build'){
            var url="api/shop/updateBuilder";
            var param = {
                'builderObject' : data
            };
            $.ajax(url, {
                data: JSON.stringify(param),
                accept: "application/json",
                contentType: "application/json",
                method: "POST"
            }).done(function(res){
                console.log('success');
                console.log(res);
            })
            .fail(function(res){
                console.log('fail');
                console.log(res);

            });  
            // $.ajax({      
            //     type:"POST",  
            //     url:url,      
            //     data:JSON.stringify(data),      
            //     success:function(args){   
            //         console.log(args);      
            //     },     
            //     error:function(e){  
            //         console.log(e);  
            //     }  
            // });  
            
        }
        
	}
    function sendChildMessage() {	
		document.getElementById("visframe").contentWindow.postMessage('sent message from parent.html', '*');
	}

    var height =  $(window).height();
    $("#visframe").height(height + 'px');

    $("#loadBtn").click(function(){
        console.log('load');
        var input = $("#inputurl").val();
        console.log(input);
        if(input.length > 0){
            //selector-loader.html?url=http://zanne.co.kr/index.php?device=mobile
            var url = "selector-loader.html?url=" + input;
            $("#visframe").attr('src', url);
        }
    });
    $("#buildBtn").click(function(){
        /*
        var iframeContents = $("#visframe").contents();        
        var hightlights = iframeContents.find(".all_highlight");
        if(hightlights.length>0){
            var sampleContent = hightlights[0];
            var parent = $(sampleContent).parents();
        } 
        */   
        document.getElementById("visframe").contentWindow.postMessage('req_obj', '*');
    });
});