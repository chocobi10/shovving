$(function() {

    var params = $.url("?");
    var requestUrl = 'api/shop/requesthtml?url=' + params.url;
    $.ajax({
        url: requestUrl,
        dataType: 'json',
        success: function(data) {
            var htmlString = data.html;
            var SCRIPT_REGEX = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi;
            while (SCRIPT_REGEX.test(htmlString)) {
                htmlString = htmlString.replace(SCRIPT_REGEX, "");
            }
            var head = htmlString.match(/<head[^<]*>[\s\S]*<\/head>/gi)[0];
            var body = htmlString.match(/<body[^<]*>[\s\S]*<\/body>/gi)[0];
            head = head.replace("<head>", "");
            head = head.replace("</head>", "");
            
            body = body.replace("<body>", "");
            body = body.replace("</body>", "");
            //console.log(head);
            
            head = "<base href=" + params.url + ">" + head; 
            head = head + '<link href="http://localhost:3000/selector.css?v=3057a" rel="stylesheet" type="text/css">';
            $('head').prepend(head);
            body = body + '<script src="http://localhost:3000/selector.js" type="text/javascript"></script>';
            $('body').html(body);
        }
    })
});