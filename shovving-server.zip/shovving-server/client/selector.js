
var blockObj = {
    block: null,
    title: null,
    image: null,
    link: null,
    price: null
};;
var isValidBlockTags = "div li tr".split(" ");
var notSelectableTags = "html body ul li table tbody th tr".split(" "),
    elemPath = "",
    elemTextMinLen = 3,
    selHlClass = "sel_highlight",
    allHlClass = "all_highlight",
    ddlSelectors;
top == self && (top.location.href = "/");

$(function() {
    $("a:not([class='feedity_framelink'])").attr("onclick", "");
    ddlSelectors = $("#ddlSelectors", top.document);
    $(":not(:empty)").on({
        mouseover: function(a) {
            a.stopPropagation();
            a.preventDefault();
            if (isValidElement($(this))) {
                var node = getCurrentNode();
                switch (node) {
                    case 'block':
                        $(this).addClass(selHlClass);
                        break;
                    default:
                        {
                            var nodeClass = 'sel_' + node;
                            $(this).addClass(nodeClass);
                        }
                        break;
                }
            }
        },
        mouseout: function(a) {
            a.stopPropagation();
            a.preventDefault();
            if (isValidElement($(this))) {
                var node = getCurrentNode();
                switch (node) {
                    case 'block':
                        $(this).removeClass(selHlClass);
                        break;
                    default:
                        {
                            var nodeClass = 'sel_' + node;
                            $(this).removeClass(nodeClass);
                        }
                        break;
                }
            }
        },
        click: function(a) {
            a.stopPropagation();
            var b = $(this);
            if (isValidElement(b)) {
                
                var node = getCurrentNode();
                a.preventDefault();
                
                if(node == 'image'){
                    var tag = getTag(b);
                    if (null == b || "" == b) return !1;
                    tag = tag.toLowerCase();
                    if(tag != 'img'){
                        tag = getTag(b.children());
                        if (null == b || "" == b) return !1;
                        tag = tag.toLowerCase();
                        if(tag == 'img'){
                            elemPath = makePath(b);
                            elemPath = elemPath.replace(/\s/g, " > ");
                            elemPath = elemPath + " > img";
                        }else{
                            a.preventDefault();
                            return false;
                        } 
                        
                    }
                }else{
                    elemPath = makePath(b);
                    elemPath = elemPath.replace(/\s/g, " > ");
                }
                updateBuilder(node);
                blockObj[node] = elemPath;
                highlightPath();
                console.log(blockObj);
            }
            return false;
        }

    });

    function isValidElement(a) {
        var b = getTag(a);
        if (null == b || "" == b) return false;
        b = b.toLowerCase();
        if (blockObj.block == null) {
            return (0 <= $.inArray(b, isValidBlockTags));
        }
        return ("a" == b || 0 > $.inArray(b, notSelectableTags));
    }

    function makePath(a) {
        if (1 != a.length) throw "Requires one element";
        for (var b, d = a.length, h = 0, g, c, f, e; d;) {
            g = a[0];
            c = g.localName;

            if (!c || "body" == c || "html" == c) break;
            f = g.id;
            e = g.className.split(" ", 1);
            c = c.toLowerCase();
            f && hasNum(f) && (f = "");
            "" != e && (hasNum(e) || /(odd|even)/i.test(e) && /(td|tr|ol|ul|li)/i.test(c)) && (e = "");
            d = c;
            1 < h && f ? d += "#" + f : 0 != h || "td" != c || isNaN(g.cellIndex) ? "" != e && 0 > e.indexOf(selHlClass) && (d += "." + e) : d = confirm("Selection seems to be a table cell. Press OK to select table rows or cancel to select the column.") ?
                "" : d + (":nth-child(" + (g.cellIndex + 1) + ")");
            1 == h && "a" == c && 0 == a.siblings("a").length && hasOnlyOneChild(a) && (b = "");
            b = d + (b ? " " + b : "");
            a = a.parent();
            d = a.length && (0 == h || !f);
            h++
        }
        return b
    }

    function highlightPath() {
        var a, b;
        elemSelected = !0;
        a = $(elemPath).filter(function() {
            b = $.trim($(this).text());
            return "" !== b && b.length >= elemTextMinLen
        });
        1 > a.length ? clearPath() : a.addClass(allHlClass)
    }

    function clearPath(a) {
        elemSelected = !1;
        elemPath && $(elemPath).removeClass(allHlClass);
        elemPath = "";
        a || updateBuilder()
    }

    function hasNum(a) {
        return /\d/.test(a)
    }

    function isFrameLink(a) {
    return "feedity_framelink" == a[0].className
}

    function getTag(a) {
        return a.prop("tagName")
    }

    function getCurrentNode() {
        var keys = Object.keys(blockObj);
        for (var i = 0; i < keys.length; i++) {
            var val = blockObj[keys[i]];
            if (val == null) return keys[i];

        }
    }
    var doubleClickCheck = false;
    function updateBuilder(a) {
        
        if(!doubleClickCheck){
            var data = {
                type : 'node',
                data : getCurrentNode()
            };
            window.parent.postMessage(data, "*");
            doubleClickCheck = true;
        }
        

        setTimeout(function(){
            doubleClickCheck = false;
        }, 100);
    }
    window.addEventListener("message", receiveParentMessage, false);

    function receiveParentMessage(e) {
        var data = {
                type : 'build',
                data : blockObj
            };
        window.parent.postMessage(data, "*");
    }
});