var cheerio = require('cheerio');
var request = require('request');
module.exports = function(Shop) {
    Shop.requesthtml = function(shopURL, cb) {
        request(shopURL, function(error, response, html) {
            if (error) {
                throw error
            };
            cb(null, html);
        });
    };

    Shop.remoteMethod(
        'requesthtml', {
            http: {
                path: '/requesthtml',
                verb: 'get'
            },
            accepts: {
                arg: 'url',
                type: 'string',
                http: {
                    source: 'query'
                }
            },
            returns: {
                arg: 'html',
                type: 'string'
            }
        }
    )

    Shop.updateBuilder = function(builderObject, cb) {
        console.log('updateBuilder');
        console.log(obj);
    }
    Shop.remoteMethod('updateBuilder', {
        accepts: [{
            arg: 'builderObject',
            type: 'object'
        }],
        returns: {
            arg: 'rtnData',
            type: 'object'
        }
    });
};